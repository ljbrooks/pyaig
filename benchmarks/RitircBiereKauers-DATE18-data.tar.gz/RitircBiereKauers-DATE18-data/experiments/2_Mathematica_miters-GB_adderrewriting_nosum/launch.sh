#!/bin/sh
name=`basename $1 .aig`
name2=`basename $2 .aig`
exec 1>"equiv-$name-$name2".log 2>"equiv-$name-$name2".err
echo "[launsh.sh] start `date`"
runlim \
  --real-time-limit=1200 \
  --space-limit=14000 \
  ./run-aigmultopoly-then-mathematica.sh $1 --full-adder-rewriting-no-sum --equivalence1 $2 --full-adder-rewriting-no-sum --equivalence2
echo "[launsh.sh] end `date`"
killall -9 WolframKernel

