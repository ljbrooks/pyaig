#!/bin/sh
case x`basename $0` in
  xsubmit.sh) run=sbatch;;
  *) run="";;
esac
echo "starting run $run" 

for i in \
  1_Mathematica_sparrc \
  1_Mathematica_sparrc_adderrewriting \
  1_Mathematica_sparrc_adderrewriting_ppe \
  1_Mathematica_sparrc_adderrewriting_ppe_nosum \
  1_Mathematica_sparrc_cs \
  1_Singular_sparrc \
  1_Singular_sparrc_adderrewriting \
  1_Singular_sparrc_adderrewriting_ppe \
  1_Singular_sparrc_adderrewriting_ppe_nosum \
  1_Singular_sparrc_cs \
  1_Mathematica_btor \
  1_Mathematica_btor_adderrewriting \
  1_Mathematica_btor_adderrewriting_ppe \
  1_Mathematica_btor_adderrewriting_ppe_nosum \
  1_Mathematica_btor_cs \
  1_Singular_btor \
  1_Singular_btor_adderrewriting \
  1_Singular_btor_adderrewriting_ppe \
  1_Singular_btor_adderrewriting_ppe_nosum \
  1_Singular_btor_cs


do
  echo "starting jobs $i" 
  cd $i ; sh run.sh ; cd ..
done

echo "finished $run" 

