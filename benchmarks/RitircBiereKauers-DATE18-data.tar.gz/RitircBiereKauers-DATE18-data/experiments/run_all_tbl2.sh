#!/bin/sh
case x`basename $0` in
  xsubmit.sh) run=sbatch;;
  *) run="";;
esac
echo "starting run $run" 

for i in \
 2_Mathematica_miters-GB \
 2_Mathematica_miters-GB_adderrewriting \
 2_Mathematica_miters-GB_adderrewriting_nosum

do
  echo "starting jobs $i" 
  cd $i ; sh run.sh ; cd ..
done

echo "finished $run" 

