#!/bin/sh
i=4
while [ $i -le 128 ]
do
  echo launching $i
  ./launch.sh ../../benchmarks/aoki/sp-ar-rc-$i.aig
  i=`expr 2 \* $i`
done
