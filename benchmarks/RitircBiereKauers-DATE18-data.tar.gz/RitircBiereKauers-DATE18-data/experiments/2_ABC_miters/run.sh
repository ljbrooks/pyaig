#!/bin/sh
for n in 4 8 16
do
  sparc=../../benchmarks/miters/sp-ar-rc-${n}-interleaved.aig
  btor=../../benchmarks/btor/btor${n}.aig
  base=sp-ar-rc-btor-miter-${n}
  runlim --time-limit=36000 --real-time-limit=36000 \
    abc -c "version" -c "cec -v -n $sparc $btor" 1>$base.log 2>$base.err
done
