#!/bin/sh
for i in 4
do
  echo launching $i
  ./launch.sh btor$i.wl
done
