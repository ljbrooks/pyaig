#!/bin/sh
for n in 4 8 16
do
  file=../../benchmarks/miters/sp-ar-rc-btor-miter-$n.cnf
  base=`basename $file .cnf`
  runlim --time-limit=36000 --real-time-limit=36000 lingeling -v $file 2>$base.err |tee -i $base.log
done
