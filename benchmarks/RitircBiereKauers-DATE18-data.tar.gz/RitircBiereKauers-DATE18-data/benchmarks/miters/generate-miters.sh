#!/bin/sh
cd aiger
./configure.sh
make
cd ..
for a in sp-ar-rc
do
  for n in 4 8 16 32 64
  do
    interleaved=${a}-${n}-interleaved
    miter=${a}-btor-miter-$n
    aiger/aiginterleave.sh ../aoki/${a}-$n.aig $interleaved.aig
    aiger/aigmiter $interleaved.aig ../btor/btor$n.aig -o ${miter}.aig -v -v
    aiger/aigtocnf ${miter}.aig ${miter}.cnf -v -v
  done
done
